# FortiMail
Basic FortiMail solution template for Azure.
